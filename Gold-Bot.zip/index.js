const express = require('express');
const app = express();
app.get("/", (request, response) => {
  const ping = new Date();
  ping.setHours(ping.getHours() - 3);
  console.log(`Ping recebido às ${ping.getUTCHours()}:${ping.getUTCMinutes()}:${ping.getUTCSeconds()}`);
  response.sendStatus(200);
});
app.listen(process.env.PORT);

const Discord = require("discord.js"); //Conexão com a livraria Discord.js
const client = new Discord.Client(); //Criação de um novo Client
const config = require("./config.json"); //Pegando o prefixo do bot para respostas de comandos

client.on("ready", () => {
  let activities = [
    `Utilize ${config.prefix}help para obter ajuda`,
  ],
    i = 0;
  setInterval(() => client.user.setActivity(`${activities[i++ % activities.length]}`, {
    type: "LISTENING"
  }), 1000 * 60);
  client.user
    .setStatus("dnd")
    .catch(console.error);
  console.log("Estou Online!")
});

client.on('guildMemberAdd',async member => {
const db = require('quick.db');
var wchannel = db.get(`bemvindo_${member.guild.id}`);

//embed
let embed = new Discord.MessageEmbed()
.setThumbnail(member.user.displayAvatarURL({ dynamic: true, format: "png", size: 1024 }))
      .setAuthor(`Bem-vindo(a)!`)
.setTitle(``)
.setDescription(`Olá ${member.user}, Seja muito Bem-vindo(a) ao Servidor!`)
.setColor('GREEN')
.setTimestamp();
//

//procurar canal
const WCHANNEL = member.guild.channels.cache.find(channel => channel.id === `${wchannel}`) 
if(WCHANNEL) { 
WCHANNEL.send(`${member.user}`,embed)
}
});

client.on('ready', () => {
  console.log(`Conectado como: ${client.user.tag}`);
})

client.on('message', async msg => {
  if (msg.author.bot) return;
  if (msg.channel.type == 'dm') return;
  if (!msg.content.startsWith(config.prefix)) return;
  const args = msg.content.slice(config.prefix.length).trim().split(/ +/g);
  const comando = args.shift().toLowerCase();

  if (comando == 'sorteio') {
    if (!msg.member.hasPermission('ADMINISTRATOR')) return;
    var regra = /^[0-9]+$/;
    if (!args[0].match(regra)) return;
    if (args[0] < 1) return;
    let owner = msg.author;
    let timer = args[0]
    args.shift()
    let premio = args.join(" ")
    if (premio == "") return;
    let embed = new Discord.MessageEmbed()
      .setAuthor(owner.tag, owner.displayAvatarURL({ format: 'png' }))
      .setColor('#ff0000')
      .setDescription(`Reaja a essa mensagem com 🎁 para participar do sorteio!!`)
      .addFields(
        { name: "Autor", value: `${owner}`, inline: true },
        { name: "Prêmio", value: `${premio}`, inline: true },
        { name: "Tempo", value: `${timer}min`, inline: true }
      )
      .setThumbnail(owner.displayAvatarURL({ format: 'png' }))
      .setTitle('Sorteio!!')
      .setFooter(`Sorteio oferecido pelo usuário: ${owner.tag}`);
    let message = await msg.channel.send(embed)
    let reactions = ['🎁']
    let participantes = []
    await message.react(reactions[0])
    const filter = (reaction) => reactions.includes(reaction.emoji.name);
    const collector = message.createReactionCollector(filter, { time: timer * 1000 * 60, dispose: true })

    collector.on('collect', async (emoji, user) => {
      switch (emoji._emoji.name) {
        case reactions[0]:
          participantes.push(user.id)
          break;
        default:
          break;
      }
    })

    collector.on('dispose', async (emoji, user) => {
      switch (emoji._emoji.name) {
        case reactions[0]:
          let index = participantes.indexOf(user.id)
          if (index > -1) {
            participantes.splice(index, 1)
          }
          break;
        default:
          break;
      }
    })

    collector.on('end', async (emoji, user) => {
      if (!participantes.length == 0) {
        let n = Math.floor(Math.random() * (participantes.length))
        let winnerID = participantes[n];
        let winner = await msg.guild.members.fetch(winnerID)
        let endmessage = new Discord.MessageEmbed()
          .setAuthor(winner.user.tag, winner.user.displayAvatarURL({ format: 'png' }))
          .setColor('#ff0000')
          .setDescription(`Vencedor do sorteio: ${winner.user.tag}`)
          .addFields(
            { name: "Autor", value: `${owner}`, inline: true },
            { name: "Prêmio", value: `${premio}`, inline: true },
            { name: "Ganhador", value: `${winner.user}`, inline: true }
          )
          .setThumbnail(winner.user.displayAvatarURL({ format: 'png' }))
          .setTitle('Sorteio Encerrado!!')
          .setFooter(`Sorteio oferecido pelo usuário: ${owner.tag}`);
        await msg.channel.send(winner.user, endmessage)
        message.delete();
      } else {
        let endmessage = new Discord.MessageEmbed()
          .setAuthor(owner.tag, owner.displayAvatarURL({ format: 'png' }))
          .setColor('#ff0000')
          .setDescription(`Nâo teve participantes no torneio.`)
          .addFields(
            { name: "Autor", value: `${owner}`, inline: true },
            { name: "Prêmio", value: `${premio}`, inline: true },
            { name: "Ganhador", value: `Não Teve`, inline: true }
          )
          .setThumbnail(owner.displayAvatarURL({ format: 'png' }))
          .setTitle('Sorteio Encerrado!!')
          .setFooter(`Sorteio oferecido pelo usuário: ${owner.tag}`);
        await msg.channel.send(endmessage)
        message.delete();
      }
    })
  }

})

client.on('message', async message => {
  if (message.author.bot) return;
  if (message.channel.type == 'dm') return;
  let member = message.mentions.members.first();
  if (member)
    if (member.id == `${client.user.id}`)
      message.channel.send(
        `**Oi eu nao respondo em ADM para saber meus comando g!help**`);
});

client.on('message', message => {
  if (message.author.bot) return;
  if (message.channel.type == 'dm') return;
  if (!message.content.toLowerCase().startsWith(config.prefix.toLowerCase())) return;
  if (message.content.startsWith(`<@!${client.user.id}>`) || message.content.startsWith(`<@${client.user.id}>`)) return;

  const args = message.content
    .trim().slice(config.prefix.length)
    .split(/ +/g);
  const command = args.shift().toLowerCase();

  try {
    const commandFile = require(`./commands/${command}.js`)
    commandFile.run(client, message, args);
  } catch (err) {
    console.error('Erro:' + err);
  }
});

client.on('guildMemberAdd', member => {
  member.guild.channels.cache.get('777980731481653259').send(`Bem vindo ${member} ao servidor!`);
});

client.on("message", msg => {
  if (msg.content === `<@${client.user.id}>`)
    msg.channel.send("Ola! eu me chamo Gold Community meu prefixo e g!") // mobile
})

client.on("message", msg => {
  if (msg.content === `<@!${client.user.id}>`)
    msg.channel.send("Ola! eu me chamo Gold Community meu prefixo e g!") // pc
})

client.login(process.env.TOKEN)