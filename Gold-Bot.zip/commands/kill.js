const Discord = require('discord.js');

exports.run = async (client, message, args) => {

var list = [
  'https://i.gifer.com/XHss.gif',
  'https://wifflegif.com/gifs/558809-akame-ga-kill-anime-gif',
];

var rand = list[Math.floor(Math.random() * list.length)];
let user = message.mentions.users.first() || client.users.cache.get(args[0]);
if (!user) {
return message.reply('lembre-se de mencionar um usuário válido para matar!');
}
/*
message.channel.send(`${message.author.username} **acaba de matar** ${user.username}! `, {files: [rand]});
*/
let avatar = message.author.displayAvatarURL({format: 'png'});
  const embed = new Discord.MessageEmbed()
        .setTitle('kill')
        .setColor('#000000')
        .setDescription(`${message.author} acabo de matar ${user}`)
        .setImage(rand)
        .setTimestamp()
        .setThumbnail(avatar)
        .setFooter('matou')
        .setAuthor(message.author.tag, avatar);
  await message.channel.send(embed);
}