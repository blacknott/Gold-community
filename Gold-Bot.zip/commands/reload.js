exports.run = (client, message, args) => {
  let user = message.author;
  if (user.id !== '585505421544914969') {
    return message.channel.send("Sorry, you must be the owner to use this command.");
  }
  
  if (args.length === 0) return message.channel.send("Use: `(seuprefix)reload <command>`");
  
  try {
    delete require.cache[require.resolve(`./${args[0]}`)];
  } catch (e) {
    return message.channel.send(`Command not found: **${args[0]}**`);
  }
  
  message.channel.send(`Reloaded command: **${args[0]}**`);
  
}