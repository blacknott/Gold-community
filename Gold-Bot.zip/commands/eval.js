const { MessageEmbed, Client } = require('discord.js');
const moment = require('moment'); moment.locale('pt-br');
const ms = require('parse-ms');

module.exports = {name: 'eval', usage: '!eval [codigo]', aliases: ['terminal', 'console'], run: async (client, message, args) => {
  
    if (message.author.id !== 'seu id') return;
        
        let code = args.slice(0).join(' ');
        if (!code) return;
        
        try {
            let ev = require("util").inspect(eval(code));
            if (ev.length > 1950) ev = ev.substr(0, 1950);
            message.channel.send(`\`\`\`js\n${ev}\`\`\``);

        } catch (err) {
            message.channel.send(`\`\`\`js\n${err}\`\`\``);
      }
    }
}