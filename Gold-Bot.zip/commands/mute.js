const { MessageEmbed } = require("discord.js");

module.exports = {
  name: "mute",
  description: "Mute anyone who break rules",
  category: "moderation",
  usage: "mute <@mention> <reason>",
  run: async (client, message, args) => {
    if (!message.member.hasPermission("MANAGE_ROLES")) {
      return message.channel.send(
        "Desculpe, mas você não tem permissão para silenciar ninguém"
      );
    }

    if (!message.guild.me.hasPermission("MANAGE_ROLES")) {
      return message.channel.send("Eu não tenho permissão para gerenciar funções.");
    }

    const user = message.mentions.members.first();
    
    if(!user) {
      return message.channel.send("Mencione o membro para quem deseja silenciar")
    }
    
    if(user.id === message.author.id) {
      return message.channel.send("Você não pode se Mutar");
    }
    
    
    let reason = args.slice(1).join(" ")
    
    
    if(!reason) {
      return message.channel.send("Por favor, dê o motivo para silenciar o membro")
    }
    
  //TIME TO LET MUTED ROLE
    
    let muterole = message.guild.roles.cache.find(x => x.name === "Muted")
    
    
      if(!muterole) {
      return message.channel.send("Esse servidor não possui um cargo com o nome `Muted`")
    }
    
    
   if(user.roles.cache.has(muterole)) {
      return message.channel.send("O usuário fornecido já está silenciado")
    }
    
  
    
    
    user.roles.add(muterole)
    
await message.channel.send(`Vc silenciou **${message.mentions.users.first().username}** devido a  \`${reason}\``)
    
    user.send(`Vc foi mutado por : **${message.guild.name}** devido \`${reason}\``)

    const embed = new Discord.MessageEmbed()
    .setTitle("Comando feito por Polarer#0001")
  }
}
