const Discord = require("discord.js");
const { MessageEmbed } = require("discord.js");
const Color = `RANDOM`;
const Random = require("srod-v2");

module.exports = {
    name: "panda",
    category: "image",
    description: "Return A Panda Image!",
    usage: "Panda",
    run: async (client, message, args) => {

        //Start

        let Data = await Random.GetAnimalImage(`Panda`, Color);

        return message.channel.send(Data);

        //End

    }
};