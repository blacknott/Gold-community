const Discord = require('discord.js');

exports.run = async (client, message, args) => {

var list = [
  'https://aminoapps.com/c/tv-tokyo/page/blog/top-10-garotas-psicopatas-em-animes/goJM_VxC6uPlvvDZpeMrK1YmamjedQ1DK7',
  'https://br.pinterest.com/pin/771382242418284503/',
];

var rand = list[Math.floor(Math.random() * list.length)];
let user = message.mentions.users.first() || client.users.cache.get(args[0]);
if (!user) {
return message.reply('lembre-se de mencionar um usuário válido para matar!');
}
/*
message.channel.send(`${message.author.username} **acaba de fuzilar** ${user.username}! `, {files: [rand]});
*/
let avatar = message.author.displayAvatarURL({format: 'png'});
  const embed = new Discord.MessageEmbed()
        .setTitle('Fuzilou')
        .setColor('#000000')
        .setDescription(`${message.author} acabo de fuzilar ${user}`)
        .setImage(rand)
        .setTimestamp()
        .setThumbnail(avatar)
        .setFooter('matou')
        .setAuthor(message.author.tag, avatar);
  await message.channel.send(embed);
}