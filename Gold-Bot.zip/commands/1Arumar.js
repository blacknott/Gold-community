const Discord = require("discord.js");

 module.exports.run = async (client, message, args) => {

     const embed = new Discord.MessageEmbed()
    .setTitle(`Boom Bot - Ajuda - ${message.member.guild.name}`)
    .setThumbnail("")
    .setColor("#00ffff")
    .setDescription(`(Prefixo: G!) <**Categorias:**`)
    .addField(`<a:emoji_44:778692895964004353>**Moderação**<a:emoji_44:778692895964004353>
    Ban,mute,kick,unmute,clear,unlock,lock,slowmode e antiraid`)
    .addField(`**Diversão**
    Gou,kiss,slap,hug,8ball,cafune,captha,cat,dog,panda,trump,fuzilar,kill,ship,corrida e avatar`)
    .addField(`**Utilitario**
    Report,sugestao,addbot,serverinfo,userinfo,botinfo,convite,uptime,say,antilink e antiraid`)
    .addField(`**Economia
    daily,atm
    
    **Ola eu me chamo Gold community fui feito pelo @Blacknott#6001 Feito 100% em node.js <:emoji_4:778285367396794369>`)
    .setImage("https://media.giphy.com/media/wxiRahtbQvT4OibnZD/giphy.gif")
  message.channel.send(embed);
 };