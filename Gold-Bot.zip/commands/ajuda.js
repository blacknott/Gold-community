const Discord = require(`discord.js`);



    exports.run = async (bot,message,args) => {

        let embed = new Discord.MessageEmbed()
        .setColor(`GOLD`)
        .setTitle(`Olá eu sou o Gold community fui feito para ajudar seu servidor, com funcionalidades`)
        .setDescription(`** Seja Bem Vindo ao painel de ajudar
 
Clique em <a:emoji_44:778692895964004353> Para ver os comandos de moderação

Clique em <:emoji_32:778650976990134303> para ver os comandos de Diversão

Clique em <a:emoji_32:778650999010361345> para ver os comande de Utilidades**
`)
.setImage("https://media.giphy.com/media/kEmdX5m75WclYQNCjO/giphy.gif")
        
        message.channel.send(message.author, embed).then(msg => { //quando enviar a mensagem...
            msg.react(`<:emoji_38:778653119440879637>`).then(() => { //quando reagir o primeiro emoji...
            msg.react(`<a:emoji_44:778692895964004353>`);
            msg.react(`<a:emoji_32:778650999010361345>`);
            msg.react(`<:emoji_32:778650976990134303>`);
            })


            const moderacao = msg.createReactionCollector((reaction, user) => reaction.emoji.id == `778692895964004353` && user.id == message.author.id, {time: 60000}) //time: tempo, 1000 = 1sec, 10000 = 10sec

const uteis = msg.createReactionCollector((reaction, user) => reaction.emoji.id == `778650999010361345` && user.id == message.author.id, {time: 60000}) //time: tempo, 1000 = 1sec, 10000 = 10sec

const brincadeiras = msg.createReactionCollector((reaction, user) => reaction.emoji.id == `778650976990134303` && user.id == message.author.id, {time: 60000}) //time: tempo, 1000 = 1sec, 10000 = 10sec

            const voltar = msg.createReactionCollector((reaction, user) => reaction.emoji.name == `778653119440879637` && user.id == message.author.id, {time: 60000})
            moderacao.on(`collect`, r =>{  //quando coletar

                let embed_two = new Discord.MessageEmbed()
                .setColor(`GOLD`)
                .setTitle(`Moderações - ${message.member.guild.name}`)
                .setDescription("`    Ban,mute,kick,unmute,clear,unlock,lock,warn,slowmode e antiraid`")
                msg.edit(embed_two)
        r.users.remove(message.author.id) //isso irá remover as reações de quem chamou o comando
            })

            uteis.on(`collect`, r =>{  //quando coletar

                let embed_two = new Discord.MessageEmbed()
                .setColor(`GOLD`)
                .setTitle(`Utilidades - ${message.member.guild.name}`)
                .setDescription("`Report,sugestao,addbot,serverinfo,userinfo,botinfo,convite,uptime,say,antilink,antiraid e Afk`")
                msg.edit(embed_two)
        r.users.remove(message.author.id) //isso irá remover as reações de quem chamou o comando
            })

            brincadeiras.on(`collect`, r =>{  //quando coletar

                let embed_two = new Discord.MessageEmbed()
                .setColor(`GOLD`)
                .setTitle(`Diversão - ${message.member.guild.name}`)
                .setDescription("`Gou,kiss,slap,hug,8ball,cafune,captha,cat,dog,panda,trump,fuzilar,kill,ship,corrida e avatar,`")
                msg.edit(embed_two)
        r.users.remove(message.author.id) //isso irá remover as reações de quem chamou o comando
            })
            
            voltar.on(`collect`, r =>{ //quando coletar
                let embed_three = new Discord.MessageEmbed()
        .setColor(`GOLD`)
        .setTitle(`Olá eu sou o Gold community fui feito para ajudar seu servidor, com funcionalidades`)
        .setDescription(`** Seja Bem Vindo ao painel de ajudar
 
Clique em <a:emoji_44:778692895964004353> Para ver os comandos de moderação

Clique em <a:emoji_32:778650999010361345> para ver os comandos de Diversão

Clique em <:emoji_32:778650976990134303> para ver os comandos de ulteis**
`)
.setImage("https://media.giphy.com/media/kEmdX5m75WclYQNCjO/giphy.gif")
msg.edit(embed_three)
        r.users.remove(message.author.id) //isso irá remover as reações de quem chamou o comando
            })
        })
    }