const Discord = require('discord.js')
const db = require('quick.db')
const config = require('../config.json')

exports.run = async (client, message, args, ops) => {
  if(!message.member.permissions.has("ADMINISTRATOR")) return message.reply("Você não tem permissão para executar esse comando")
let
   channel = message.mentions.channels.first() || message.guild.channels.cache.get(args[0]);

  if(!args[0]) return message.reply("mencione um canal")

  let wc = db.get(`welcomechannel_${message.guild.id}`)

  try {
      db.set(`bemvindo_${message.guild.id}`,  channel.id)
      message.channel.send(new Discord.MessageEmbed()
      .setDescription(`Boas-vindas setado no canal: **${channel}**`)
      .setColor(`GREEN`)) 
  } catch (err) {
    console.error("Erro: " + err)
  }
}