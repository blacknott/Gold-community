const { MessageEmbed } = require('discord.js');
const axios = require('axios');

module.exports = {
    name: "binary",
    category: "extra",
    run: async (client, message, args) => {
        const url = `http://some-random-api.ml/binary?text=${args}`;

        let response, data;
        try {
            response = await axios.get(url);
            data = response.data;
        } catch (e) {
            return message.channel.send(`**Escreva seu texto, para eu traduzir em código binário! (caso tenha colocado aceentos, reescreva sem os mesmos pois eu não reconheço eles!)**`)
        }

        const embed = new MessageEmbed()
            .setTitle('Texto em código binário')
            .setDescription(data.binary)
            .setColor('RANDOM')
            .setFooter('O que será que está escrito? :o')
            
             
            message.delete().catch(O_o => {});


        await message.channel.send(embed)
    }
}