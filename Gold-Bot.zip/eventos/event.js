const { readdirSync } = require("fs")

module.exports.run = (client) => {
  for(let dir of readdirSync("./eventos/")){
    for(let file of readdirSync(`./eventos/${dir}`).filter(n => n.endsWith(".js"))){
      let pull = require(`../eventos/${dir}/${file}`)
      var nome = file.split(".").shift()
      client.on(nome, pull.bind(null, client))
    }
  }
  console.log(`Eventos carregados: ${client._eventsCount}`)
}